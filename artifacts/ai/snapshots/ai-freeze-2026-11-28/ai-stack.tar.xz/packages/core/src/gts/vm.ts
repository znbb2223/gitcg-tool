// Copyright (C) 2026 Piovium Labs
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as
// published by the Free Software Foundation, either version 3 of the
// License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

export { default } from "./vm_impl/index";
export { CharacterModel, CharacterViewModel, type CharacterVMMeta } from "./vm_impl/character";
export { CardModel, CardViewModel } from "./vm_impl/card";
export {
  EntityModel,
  EntityViewModel,
  type DefaultEntityVMMeta,
  type EntityVMMeta,
  type WithIdVMMeta,
} from "./vm_impl/entity";
export {
  CharacterSkillModel,
  CharacterSkillViewModel,
  type CharacterSkillVMMeta,
} from "./vm_impl/skill";
export {
  AttachmentModel,
  AttachmentViewModel,
} from "./vm_impl/attachment";
