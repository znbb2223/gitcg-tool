// Copyright (C) 2024-2025 Guyutongxue
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as
// published by the Free Software Foundation, either version 3 of the
// License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

import { $, DamageType, DiceType } from "@gi-tcg/core/data";

/**
 * @id 112091
 * @name 破局
 * @description
 * 此状态初始具有1层「破局」；重复附属时，叠加1层「破局」。「破局」最多可以叠加到3层。
 * 结束阶段：叠加1层「破局」。
 * 所附属角色普通攻击时：如果「破局」已有2层，则消耗2层「破局」，使造成的物理伤害转换为水元素伤害，并抓1张牌。
 */
define status {
  id 112091 as BreakthroughStatus;
  variable "break", 1 {
    append;
    range 3;
  };
  on endPhase {
    :variables.break += 1;
  };
  on modifySkillDamageType {
    when :( :e.viaSkillType("normal") && :variables.break >= 2 );
    :variables.break -= 2;
    :e.changeDamageType(DamageType.Hydro);
    :drawCards(1);
  };
};

/**
 * @id 112092
 * @name 玄掷玲珑
 * @description
 * 我方角色普通攻击后：造成1点水元素伤害。
 * 持续回合：2
 */
define combatStatus {
  id 112092 as ExquisiteThrow;
  duration 2;
  on useSkill {
    when :( :e.isSkillType("normal") );
    :damage(DamageType.Hydro, 1);
  };
};

/**
 * @id 12091
 * @name 潜形隐曜弓
 * @cost 1*Hydro, 2*Void
 * @description
 * 造成2点物理伤害。
 */
define skill {
  id 12091 as StealthyBowshot;
  skillType normal;
  cost DiceType.Hydro, 1;
  cost DiceType.Void, 2;
  :damage(DamageType.Physical, 2);
};

/**
 * @id 12092
 * @name 萦络纵命索
 * @cost 3*Hydro
 * @description
 * 造成3点水元素伤害，此角色的破局层数+2。
 */
define skill {
  id 12092 as LingeringLifeline;
  skillType elemental;
  cost DiceType.Hydro, 3;
  :damage(DamageType.Hydro, 3);
  const breakSt = :self.hasStatus(BreakthroughStatus)!;
  breakSt.variables.break += 2;
};

/**
 * @id 12093
 * @name 渊图玲珑骰
 * @cost 3*Hydro, 3*Energy
 * @description
 * 造成3点水元素伤害，生成玄掷玲珑。
 */
define skill {
  id 12093 as DepthclarionDice;
  skillType burst;
  cost DiceType.Hydro, 3;
  cost DiceType.Energy, 3;
  :damage(DamageType.Hydro, 3);
  :combatStatus(ExquisiteThrow);
};

/**
 * @id 12094
 * @name 破局
 * @cost
 * @description
 * 【被动】战斗开始时，初始附属破局。
 */
define skill {
  id 12094 as Breakthrough;
  skillType passive {
    on battleBegin {
      :characterStatus(BreakthroughStatus);
    };
    on revive {
      :characterStatus(BreakthroughStatus);
    };
  };
};

/**
 * @id 1209
 * @name 夜兰
 * @hp 11
 * @energy 3
 * @description
 * 天地一渺渺，幽客自来去。
 */
define character {
  id 1209 as Yelan;
  since "v4.3.0";
  tags hydro, bow, liyue;
  health 11;
  energy 3;
  skills StealthyBowshot, LingeringLifeline, DepthclarionDice, Breakthrough;
};

/**
 * @id 212091
 * @name 猜先有方
 * @cost 3*Hydro
 * @description
 * 战斗行动：我方出战角色为夜兰时，装备此牌。
 * 夜兰装备此牌后，立刻使用一次萦络纵命索。
 * 投掷阶段：装备有此牌的夜兰在场，则我方队伍中每有1种元素类型，就使1个元素骰总是投出万能元素。（最多3个）
 * （牌组中包含夜兰，才能加入牌组）
 */
define card {
  id 212091 as TurnControl;
  since "v4.3.0";
  cost DiceType.Hydro, 3;
  talent Yelan {
    on staged {
      :useSkill(LingeringLifeline);
    };
    on roll {
      const elements = new Set(
        :queryAll($.my.character.includesDefeated).map((char) =>
          char.element(),
        ),
      );
      :e.fixDice(DiceType.Omni, Math.min(elements.size, 3));
    };
  };
};
