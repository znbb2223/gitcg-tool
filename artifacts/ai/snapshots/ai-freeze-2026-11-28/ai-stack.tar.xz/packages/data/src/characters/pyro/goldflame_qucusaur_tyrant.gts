// Copyright (C) 2026 Piovium Labs
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as
// published by the Free Software Foundation, either version 3 of the
// License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

import { $, DamageType, DiceType } from "@gi-tcg/core/data";

/**
 * @id 123061
 * @name 金焰形态
 * @description
 * 结束阶段：如果所附属角色为出战角色，则造成1点火元素伤害，对所有敌方后台角色造成1点穿透伤害。
 * 可用次数：1（可叠加，没有上限）
 */
define status {
  id 123061 as GoldflameState;
  since "v6.4.0";
  on endPhase {
    when :( :self.master.isActive() );
    usage 1 {
      append;
    };
    const chosen = :query($.my.equipped.def(FlamelordsBlessing))
      ? :random(:player.hands)
      : null;
    const damageValue = 1 + (chosen?.diceCost() ?? 0);
    :damage(DamageType.Piercing, 1, $.opp.standby);
    :damage(DamageType.Pyro, damageValue);
    if (chosen) {
      :discard(chosen);
    }
  };
};

/**
 * @id 123062
 * @name 飞旋
 * @description
 * 自身下次受到的伤害-1。
 * 可用次数：1（可叠加，没有上限）
 */
define status {
  id 123062 as FlyingSwirl;
  since "v6.4.0";
  tags barrier;
  on decreaseDamaged {
    usage 1 {
      append;
    };
    :e.decreaseDamage(1);
  };
};

/**
 * @id 23061
 * @name 翼斩
 * @cost 1*Pyro, 2*Void
 * @description
 * 造成2点物理伤害。
 */
define skill {
  id 23061 as Wingcleave;
  skillType normal;
  cost DiceType.Pyro, 1;
  cost DiceType.Void, 2;
  :damage(DamageType.Physical, 2);
};

/**
 * @id 23062
 * @name 升腾炽风
 * @cost 3*Pyro
 * @description
 * 造成1点火元素伤害，自身附属2层飞旋。
 */
define skill {
  id 23062 as HotRisingWind;
  skillType elemental;
  cost DiceType.Pyro, 3;
  :damage(DamageType.Pyro, 1);
  :characterStatus(FlyingSwirl, :self, {
    overrideVariables: {
      usage: 2,
    },
  });
};

/**
 * @id 23063
 * @name 金焰爆轰
 * @cost 3*Pyro, 2*Energy
 * @description
 * 造成3点火元素伤害，对所有敌方后台角色造成1点穿透伤害，自身附属1层金焰形态。
 */
define skill {
  id 23063 as GoldflameExplosion;
  skillType burst;
  cost DiceType.Pyro, 3;
  cost DiceType.Energy, 2;
  :damage(DamageType.Piercing, 1, $.opp.standby);
  :damage(DamageType.Pyro, 3);
  :characterStatus(GoldflameState, :self);
};

/**
 * @id 23064
 * @name 古老者的血脉
 * @cost
 * @description
 * 【被动】偶数行动阶段开始时：自身附属1层金焰形态。
 */
define skill {
  id 23064 as AncientBloodline;
  skillType passive {
    on actionPhase {
      when :( :roundNumber % 2 === 0 );
      :characterStatus(GoldflameState, :self);
    };
  };
};

/**
 * @id 2306
 * @name 金焰绒翼龙暴君
 * @hp 11
 * @energy 2
 * @description
 * 因承受了如今龙众的身躯无法驭使的伟力，而拥有超然形体的异种绒翼龙。
 */
define character {
  id 2306 as GoldflameQucusaurTyrant;
  since "v6.4.0";
  tags pyro, monster;
  health 11;
  energy 2;
  skills Wingcleave, HotRisingWind, GoldflameExplosion, AncientBloodline;
};

/**
 * @id 223061
 * @name 「焰主之祝」
 * @cost 3*Pyro, 2*Energy
 * @description
 * 战斗行动：我方出战角色为金焰绒翼龙暴君时，装备此牌。
 * 金焰绒翼龙暴君装备此牌后，立刻使用一次金焰爆轰。
 * 我方金焰形态触发时，额外舍弃1张随机手牌，金焰形态造成的伤害额外提高，其数值等同于所舍弃手牌的当前元素骰费用。
 * （牌组中包含金焰绒翼龙暴君，才能加入牌组）
 */
define card {
  id 223061 as FlamelordsBlessing;
  since "v6.4.0";
  cost DiceType.Pyro, 3;
  cost DiceType.Energy, 2;
  talent GoldflameQucusaurTyrant {
    on staged {
      :useSkill(GoldflameExplosion);
    };
  };
};
