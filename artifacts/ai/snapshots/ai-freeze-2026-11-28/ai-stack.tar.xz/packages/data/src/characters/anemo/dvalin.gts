// Copyright (C) 2024-2025 Guyutongxue
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as
// published by the Free Software Foundation, either version 3 of the
// License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

import { $, DamageType, DiceType } from "@gi-tcg/core/data";

/**
 * @id 125024
 * @name 龙威
 * @description
 * 特瓦林下次造成的伤害+1
 */
define status {
  id 125024 as DraconicMajesty;
  reserved;
};

/**
 * @id 25026
 * @name 终幕涤流
 * @cost
 * @description
 * （需准备1个行动轮）
 * 对上一个敌方后台角色造成2点风元素伤害。（敌方没有后台角色时，改为对出战角色造成伤害）
 */
define skill {
  id 25026 as UltimateCleansing;
  skillType elemental;
  prepared;
  if (:query($.opp.prev)) {
    :damage(DamageType.Anemo, 2, $.opp.prev);
  } else {
    :damage(DamageType.Anemo, 2);
  }
};

/**
 * @id 125023
 * @name 风龙吐息
 * @description
 * 本角色将在下次行动时，直接使用技能：终幕涤流。
 */
define status {
  id 125023 as DvalinsSigh01;
  prepare UltimateCleansing;
};

/**
 * @id 25025
 * @name 长延涤流
 * @cost
 * @description
 * （需准备1个行动轮）
 * 对下一个敌方后台角色造成1点风元素伤害，然后准备技能：终幕涤流。（敌方没有后台角色时，改为对出战角色造成伤害）
 */
define skill {
  id 25025 as PerpetualCleansing;
  skillType elemental;
  prepared;
  if (:query($.opp.next)) {
    :damage(DamageType.Anemo, 1, $.opp.next);
  } else {
    :damage(DamageType.Anemo, 1);
  }
  :characterStatus(DvalinsSigh01);
};

/**
 * @id 125022
 * @name 风龙吐息
 * @description
 * 本角色将在下次行动时，直接使用技能：长延涤流。
 */
define status {
  id 125022 as DvalinsSigh;
  prepare PerpetualCleansing;
};

/**
 * @id 125021
 * @name 坍毁
 * @description
 * 所附属角色受到的物理伤害或风元素伤害+2。
 * 可用次数：1
 */
define status {
  id 125021 as TotalCollapse;
  on increaseDamaged {
    when :(
      ([DamageType.Physical, DamageType.Anemo] as DamageType[]).includes(
        :e.type,
      )
    );
    usage 1;
    :e.increaseDamage(2);
  };
};

/**
 * @id 125025
 * @name 坍裂的高台
 * @description
 * 结束阶段：对我方出战角色附属坍毁。
 */
define combatStatus {
  id 125025 as CollapsingPlatform;
  reserved;
};

/**
 * @id 25021
 * @name 裂爪横击
 * @cost 1*Anemo, 2*Void
 * @description
 * 造成2点物理伤害。
 */
define skill {
  id 25021 as LaceratingSlash;
  skillType normal;
  cost DiceType.Anemo, 1;
  cost DiceType.Void, 2;
  :damage(DamageType.Physical, 2);
};

/**
 * @id 25022
 * @name 暴风轰击
 * @cost 3*Anemo
 * @description
 * 造成2点风元素伤害，目标角色附属坍毁。
 */
define skill {
  id 25022 as TempestuousBarrage;
  skillType elemental;
  cost DiceType.Anemo, 3;
  :damage(DamageType.Anemo, 2);
  :characterStatus(TotalCollapse, $.opp.active);
};

/**
 * @id 25023
 * @name 风龙涤流
 * @cost 5*Anemo
 * @description
 * 造成2点风元素伤害，然后分别准备技能：长延涤流和终幕涤流。
 */
define skill {
  id 25023 as DvalinsCleansing;
  skillType elemental;
  cost DiceType.Anemo, 5;
  :damage(DamageType.Anemo, 2);
  :characterStatus(DvalinsSigh);
};

/**
 * @id 25024
 * @name 终天闭幕曲
 * @cost 4*Anemo, 2*Energy
 * @description
 * 造成5点风元素伤害，所有敌方后台角色附属坍毁。
 */
define skill {
  id 25024 as CaelestinumFinaleTermini;
  skillType burst;
  cost DiceType.Anemo, 4;
  cost DiceType.Energy, 2;
  :damage(DamageType.Anemo, 5);
  :characterStatus(TotalCollapse, $.opp.standby);
};

/**
 * @id 2502
 * @name 特瓦林
 * @hp 10
 * @energy 2
 * @description
 * 「如果你曾是我，看见过你在蓝蓝的天上滑翔的孤高模样，见识过你的美丽身姿就好了。」
 * 「如此，你就会明白，这样的天空与大地，是值得为之奋战的。」
 */
define character {
  id 2502 as Dvalin;
  since "v4.3.0";
  tags anemo, monster;
  health 10;
  energy 2;
  skills LaceratingSlash,
    TempestuousBarrage,
    DvalinsCleansing,
    CaelestinumFinaleTermini,
    PerpetualCleansing,
    UltimateCleansing;
};

/**
 * @id 225021
 * @name 毁裂风涡
 * @cost 3*Anemo
 * @description
 * 战斗行动：我方出战角色为特瓦林时，装备此牌。
 * 特瓦林装备此牌后，立刻使用一次暴风轰击。
 * 装备有此牌的特瓦林在场时，敌方角色所附属的坍毁状态被移除后：对下一个敌方后台角色附属坍毁。（每回合1次）
 * （牌组中包含特瓦林，才能加入牌组）
 */
define card {
  id 225021 as RendingVortex;
  since "v4.3.0";
  cost DiceType.Anemo, 3;
  talent Dvalin {
    on staged {
      :useSkill(TempestuousBarrage);
    };
    on entityDispose {
      when :(
        :e.entity.definition.id === TotalCollapse && !:e.entity.isMine()
      );
      listenTo all;
      usage perRound, 1;
      :characterStatus(TotalCollapse, $.opp.next);
    };
  };
};
