// Copyright (C) 2024-2025 Guyutongxue
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as
// published by the Free Software Foundation, either version 3 of the
// License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

import { $, DamageType, DiceType } from "@gi-tcg/core/data";

/**
 * @id 114021
 * @name 雷狼
 * @description
 * 所附属角色使用普通攻击或元素战技后：造成2点雷元素伤害。
 * 持续回合：2
 */
define status {
  id 114021 as TheWolfWithin;
  duration 2;
  on useSkill {
    when :( :e.isSkillType("normal") || :e.isSkillType("elemental") );
    :damage(DamageType.Electro, 2);
  };
};

/**
 * @id 14021
 * @name 钢脊
 * @cost 1*Electro, 2*Void
 * @description
 * 造成2点物理伤害。
 */
define skill {
  id 14021 as SteelFang;
  skillType normal;
  cost DiceType.Electro, 1;
  cost DiceType.Void, 2;
  :damage(DamageType.Physical, 2);
};

/**
 * @id 14022
 * @name 利爪与苍雷
 * @cost 3*Electro
 * @description
 * 造成3点雷元素伤害。
 */
define skill {
  id 14022 as ClawAndThunder;
  skillType elemental;
  cost DiceType.Electro, 3;
  :damage(DamageType.Electro, 3);
};

/**
 * @id 14023
 * @name 雷牙
 * @cost 3*Electro, 2*Energy
 * @description
 * 造成3点雷元素伤害，本角色附属雷狼。
 */
define skill {
  id 14023 as LightningFang;
  skillType burst;
  cost DiceType.Electro, 3;
  cost DiceType.Energy, 2;
  :damage(DamageType.Electro, 3);
  :characterStatus(TheWolfWithin);
};

/**
 * @id 1402
 * @name 雷泽
 * @hp 10
 * @energy 2
 * @description
 * 「牌，难。」
 * 「但，有朋友…」
 */
define character {
  id 1402 as Razor;
  since "v3.3.0";
  tags electro, claymore, mondstadt;
  health 10;
  energy 2;
  skills SteelFang, ClawAndThunder, LightningFang;
};

/**
 * @id 214021
 * @name 觉醒
 * @cost 3*Electro
 * @description
 * 战斗行动：我方出战角色为雷泽时，装备此牌。
 * 雷泽装备此牌后，立刻使用一次利爪与苍雷。
 * 装备有此牌的雷泽使用利爪与苍雷后：使我方一个雷元素角色获得1点充能。（每回合1次，出战角色优先）
 * （牌组中包含雷泽，才能加入牌组）
 */
define card {
  id 214021 as Awakening;
  since "v3.3.0";
  cost DiceType.Electro, 3;
  talent Razor {
    on staged {
      :useSkill(ClawAndThunder);
    };
    on useSkill {
      when :( :e.skill.definition.id === ClawAndThunder );
      usage perRound, 1;
      :gainEnergy(
        1,
        $.my.character
          .tag("electro")
          .intersection($.any.var("energy", "<", "maxEnergy"))
          .limit(1),
      );
    };
  };
};

/**
 * @id 214022
 * @name 苍雷奔涌
 * @cost 2*Electro
 * @description
 * 战斗行动：我方出战角色为雷泽时，装备此牌。
 * 我方雷泽如果未附属雷狼，则自身附属持续回合为1的雷狼。
 * 装备有此牌的雷泽附属雷狼期间，我方雷狼造成的伤害+1。
 * （牌组中包含雷泽，才能加入牌组）
 */
define card {
  id 214022 as SurgeOfLightning;
  since "v7.1.0";
  cost DiceType.Electro, 2;
  tags hexenzirkel;
  talent Razor, action {
    on staged {
      if (!:e.targets[0].hasStatus(TheWolfWithin)) {
        :characterStatus(TheWolfWithin, :e.targets[0], {
          overrideVariables: { duration: 1 },
        });
      }
    }
    on increaseDamage {
      when :( :e.source.definition.id === TheWolfWithin );
      :e.increaseDamage(1);
    }
  }
}
