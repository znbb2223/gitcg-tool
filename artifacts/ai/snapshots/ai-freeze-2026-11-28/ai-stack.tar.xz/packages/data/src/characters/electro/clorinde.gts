// Copyright (C) 2024-2025 Guyutongxue
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as
// published by the Free Software Foundation, either version 3 of the
// License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

import { $, DamageType, DiceType, type SkillHandle } from "@gi-tcg/core/data";
import { BondOfLife } from "../../commons.gts";

/**
 * @id 114121
 * @name 夜巡
 * @description
 * 角色受到狩夜之巡以外的治疗时，改为附属等量的生命之契。
 * 所附属角色使用普通攻击时：造成的物理伤害变为雷元素伤害，并使自身附属2层生命之契。
 * 持续回合：1
 */
define status {
  id 114121 as NightVigil;
  since "v5.3.0";
  duration 1;
  on cancelHealed {
    when :( :e.via.definition.id !== HuntersVigil );
    const value = :e.expectedValue;
    :e.cancel();
    if (value > 0) {
      :characterStatus(BondOfLife, :self.master, {
        overrideVariables: {
          usage: value,
        },
      });
    }
  };
  on modifySkillDamageType {
    when :( :e.viaSkillType("normal") );
    if (:e.type === DamageType.Physical) {
      :e.changeDamageType(DamageType.Electro);
    }
    :characterStatus(BondOfLife, :self.master, {
      overrideVariables: {
        usage: 2,
      },
    });
  };
  on deductVoidDiceSkill {
    when :( :e.action.skill.definition.id === OathOfHuntingShadows );
    :e.deductVoidCost(1);
  };
};

/**
 * @id 114122
 * @name 破夜的明焰（生效中）
 * @description
 * 本回合克洛琳德下次造成的伤害+1。
 * 可用次数：1(可叠加，最多叠加到+3)
 */
define status {
  id 114122 as DarkshatteringFlameInEffect;
  since "v5.3.0";
  oneDuration;
  // 只叠加可用次数，不叠加伤害
  on increaseSkillDamage {
    usage 1 {
      append 3;
    };
    :e.increaseDamage(1);
  };
};

/**
 * @id 14121
 * @name 逐影之誓
 * @cost 1*Electro, 2*Void
 * @description
 * 造成1点物理伤害。如果本角色附属夜巡，则此技能少花费1个无色元素。
 */
define skill {
  id 14121 as OathOfHuntingShadows;
  skillType normal;
  cost DiceType.Electro, 1;
  cost DiceType.Void, 2;
  :damage(DamageType.Physical, 1);
};

/**
 * @id 14122
 * @name 狩夜之巡
 * @cost 2*Electro
 * @description
 * 自身附属夜巡，移除自身所有生命之契。然后根据所移除的层数，造成雷元素伤害，并治疗自身。（伤害和治疗最多4点）
 */
define skill {
  id 14122 as HuntersVigil;
  skillType elemental;
  cost DiceType.Electro, 2;
  :characterStatus(NightVigil, :self);
  const st = :self.hasStatus(BondOfLife);
  let value = 0;
  if (st) {
    value = Math.min(st.variables.usage!, 4);
    :dispose(st);
  }
  if (value > 0) {
    :damage(DamageType.Electro, value);
  }
  :heal(value, :self);
};

/**
 * @id 14123
 * @name 残光将终
 * @cost 3*Electro, 2*Energy
 * @description
 * 造成3点雷元素伤害，自身附属4层生命之契。
 */
define skill {
  id 14123 as LastLightfall;
  skillType burst;
  cost DiceType.Electro, 3;
  cost DiceType.Energy, 2;
  :damage(DamageType.Electro, 3);
  :characterStatus(BondOfLife, :self, {
    overrideVariables: {
      usage: 4,
    },
  });
};

/**
 * @id 1412
 * @name 克洛琳德
 * @hp 10
 * @energy 2
 * @description
 * 洞灭魔影，持护长夜。
 */
define character {
  id 1412 as Clorinde;
  since "v5.3.0";
  tags electro, sword, fontaine, pneuma;
  health 10;
  energy 2;
  skills OathOfHuntingShadows, HuntersVigil, LastLightfall;
};

/**
 * @id 214121
 * @name 破夜的明焰
 * @cost 2*Electro
 * @description
 * 战斗行动：我方出战角色为克洛琳德时，装备此牌。
 * 克洛琳德装备此牌后，立刻使用一次狩夜之巡。
 * 我方角色引发雷元素相关反应后:本回合克洛琳德下次造成的伤害+1。(可叠加，最多叠加到+3)
 * （牌组中包含克洛琳德，才能加入牌组）
 */
define card {
  id 214121 as DarkshatteringFlame;
  since "v5.3.0";
  cost DiceType.Electro, 2;
  talent Clorinde {
    on staged {
      :useSkill(HuntersVigil);
    };
    on useSkill {
      when :( :hasPhaseReaction("my", (e) => e.relatedTo(DamageType.Electro)) );
      listenTo samePlayer;
      :characterStatus(DarkshatteringFlameInEffect, :self.master);
    };
  };
};
