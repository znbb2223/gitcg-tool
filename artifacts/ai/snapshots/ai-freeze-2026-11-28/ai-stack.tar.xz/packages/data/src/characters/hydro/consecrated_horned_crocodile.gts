// Copyright (C) 2024-2025 Guyutongxue
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as
// published by the Free Software Foundation, either version 3 of the
// License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

import { $, DamageType, DiceType } from "@gi-tcg/core/data";
import { BonecrunchersEnergyBlock } from "../../cards/event/other.gts";

/**
 * @id 22071
 * @name 尖牙噬咬
 * @cost 1*Hydro, 2*Void
 * @description
 * 造成2点物理伤害。
 */
define skill {
  id 22071 as FangBite;
  skillType normal;
  cost DiceType.Hydro, 1;
  cost DiceType.Void, 2;
  :damage(DamageType.Physical, 2);
};

/**
 * @id 22072
 * @name 鳄齿锐波
 * @cost 3*Hydro
 * @description
 * 造成3点水元素伤害，将至多1张当前元素骰费用最高的手牌置入牌组底，生成手牌噬骸能量块。
 */
define skill {
  id 22072 as SawtoothedSurge;
  skillType elemental;
  cost DiceType.Hydro, 3;
  :damage(DamageType.Hydro, 3);
  const undrawn = :maxCostHands(1);
  :undrawCards(undrawn, "bottom");
  :createHandCard(BonecrunchersEnergyBlock);
};

/**
 * @id 22073
 * @name 凶鳄狂浪
 * @cost 3*Hydro, 2*Energy
 * @description
 * 造成4点水元素伤害，舍弃至多3张噬骸能量块，每舍弃1张，治疗我方受伤最多的角色1点，并使其获得1点最大生命值。
 */
define skill {
  id 22073 as ReptilianRage;
  skillType burst;
  cost DiceType.Hydro, 3;
  cost DiceType.Energy, 2;
  :damage(DamageType.Hydro, 4);
  const blocks = :player.hands
    .filter((card) => card.definition.id === BonecrunchersEnergyBlock)
    .slice(0, 3);
  :discard(...blocks);
  const target = :query($.macros.myMostInjured);
  if (target) {
    :heal(blocks.length, target);
    :increaseMaxHealth(blocks.length, target);
  }
};

/**
 * @id 22074
 * @name 圣骸感应
 * @cost
 * @description
 * 【被动】我方打出或舍弃噬骸能量块后，治疗我方受伤最多的角色1点。
 */
define skill {
  id 22074 as ConsecratedSenses;
  skillType passive {
    on playCard {
      when :( :e.card.definition.id === BonecrunchersEnergyBlock );
      :heal(1, $.macros.myMostInjured);
    };
    on discard {
      when :( :e.entity.definition.id === BonecrunchersEnergyBlock );
      :heal(1, $.macros.myMostInjured);
    };
  };
};

/**
 * @id 2207
 * @name 圣骸角鳄
 * @hp 11
 * @energy 2
 * @description
 * 因为啃噬伟大的生命体，而扭曲异变的爬行动物，驾驭着多变的水流。
 */
define character {
  id 2207 as ConsecratedHornedCrocodile;
  since "v6.3.0";
  tags hydro, monster, sacread;
  health 11;
  energy 2;
  skills FangBite, SawtoothedSurge, ReptilianRage, ConsecratedSenses;
};

/**
 * @id 222071
 * @name 亡水溢流
 * @cost 1*Hydro
 * @description
 * 快速行动：装备给我方的圣骸角鳄。
 * 入场时：生成手牌噬骸能量块。
 * 装备有此牌的圣骸角鳄在场时，我方使用噬骸能量块后，治疗我方受伤最多的角色1点。
 * （牌组中包含圣骸角鳄，才能加入牌组）
 */
define card {
  id 222071 as DeathlyOverflow;
  since "v6.3.0";
  cost DiceType.Hydro, 1;
  talent ConsecratedHornedCrocodile, none {
    on staged {
      :createHandCard(BonecrunchersEnergyBlock);
    };
    on playCard {
      when :( :e.card.definition.id === BonecrunchersEnergyBlock );
      :heal(1, $.macros.myMostInjured);
    };
  };
};
