// Copyright (C) 2024-2025 Guyutongxue
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Affero General Public License as
// published by the Free Software Foundation, either version 3 of the
// License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Affero General Public License for more details.
//
// You should have received a copy of the GNU Affero General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

import {
  $,
  DamageType,
  DiceType,
  type CharacterHandle,
  type SkillHandle,
} from "@gi-tcg/core/data";

/**
 * @id 12104
 * @name 衡平推裁
 * @cost
 * @description
 * （需准备1个行动轮）
 * 造成2点水元素伤害，如果本角色生命值至少为6，则此伤害+1并对自身造成1点穿透伤害。
 */
define skill {
  id 12104 as EquitableJudgment;
  skillType normal;
  prepared;
  if (:self.health >= 6) {
    :damage(DamageType.Hydro, 3);
    :damage(DamageType.Piercing, 1, :self);
  } else {
    :damage(DamageType.Hydro, 2);
  }
};

/**
 * @id 112102
 * @name 衡平推裁
 * @description
 * 本角色将在下次行动时，直接使用技能：衡平推裁。
 */
define status {
  id 112102 as EquitableJudgmentStatus;
  prepare EquitableJudgment;
};

/**
 * @id 112103
 * @name 遗龙之荣
 * @description
 * 角色造成的伤害+1。
 * 可用次数：2
 */
define status {
  id 112103 as PastDraconicGlories;
  on increaseSkillDamage {
    usage 2;
    :e.increaseDamage(1);
  };
};

/**
 * @id 112101
 * @name 源水之滴
 * @description
 * 那维莱特进行普通攻击后：治疗那维莱特2点。如果那维莱特是我方「出战角色」，则准备技能：衡平推裁。
 * 可用次数：1（可叠加，最多叠加到3次）
 */
define combatStatus {
  id 112101 as SourcewaterDroplet;
  usage 1 {
    append 3;
  };
};

/**
 * @id 12101
 * @name 如水从平
 * @cost 1*Hydro, 2*Void
 * @description
 * 造成1点水元素伤害。
 */
define skill {
  id 12101 as AsWaterSeeksEquilibrium;
  skillType normal;
  cost DiceType.Hydro, 1;
  cost DiceType.Void, 2;
  :damage(DamageType.Hydro, 1);
};

/**
 * @id 12102
 * @name 泪水啊，我必偿还
 * @cost 3*Hydro
 * @description
 * 造成2点水元素伤害，生成源水之滴。
 */
define skill {
  id 12102 as OTearsIShallRepay;
  skillType elemental;
  cost DiceType.Hydro, 3;
  :damage(DamageType.Hydro, 2);
  :combatStatus(SourcewaterDroplet);
};

/**
 * @id 12103
 * @name 潮水啊，我已归来
 * @cost 3*Hydro, 2*Energy
 * @description
 * 造成2点水元素伤害，对所有后台敌人造成1点穿透伤害，生成可用次数为2的源水之滴。
 */
define skill {
  id 12103 as OTidesIHaveReturned;
  skillType burst;
  cost DiceType.Hydro, 3;
  cost DiceType.Energy, 2;
  :damage(DamageType.Piercing, 1, $.opp.standby);
  :damage(DamageType.Hydro, 2);
  :combatStatus(SourcewaterDroplet, "my", {
    overrideVariables: {
      usage: 2,
    },
  });
};

/**
 * @id 12105
 * @name 源水之滴
 * @cost
 * @description
 * 
 */
define skill {
  id 12105 as SourcewaterDropletSkill;
  skillType passive {
    on useSkill {
      when :(
        :e.isSkillType("normal") &&
          :query($.my.combatStatus.def(SourcewaterDroplet))
      );
      const droplet = :query($.my.combatStatus.def(SourcewaterDroplet));
      droplet?.consumeUsage();
      :heal(2, :self);
      if (:self.isActive()) {
        :characterStatus(EquitableJudgmentStatus, :self);
      }
    };
  };
};

/**
 * @id 1210
 * @name 那维莱特
 * @hp 11
 * @energy 2
 * @description
 * 凡高大者，无不蔑视。
 */
define character {
  id 1210 as Neuvillette;
  since "v4.5.0";
  tags hydro, catalyst, fontaine, ousia;
  health 11;
  energy 2;
  skills AsWaterSeeksEquilibrium,
    OTearsIShallRepay,
    OTidesIHaveReturned,
    EquitableJudgment,
    SourcewaterDropletSkill;
};

/**
 * @id 212101
 * @name 古海孑遗的权柄
 * @cost 1*Hydro, 2*Void
 * @description
 * 战斗行动：我方出战角色为那维莱特时，装备此牌。
 * 那维莱特装备此牌后，立刻使用一次如水从平。
 * 我方角色引发水元素相关反应后：装备有此牌的那维莱特接下来2次造成的伤害+1。
 * （牌组中包含那维莱特，才能加入牌组）
 */
define card {
  id 212101 as HeirToTheAncientSeasAuthority;
  since "v4.5.0";
  cost DiceType.Hydro, 1;
  cost DiceType.Void, 2;
  talent Neuvillette {
    on staged {
      :useSkill(AsWaterSeeksEquilibrium);
    };
    on useSkill {
      when :( :hasPhaseReaction("my", (e) => e.relatedTo(DamageType.Hydro)) );
      listenTo samePlayer;
      :characterStatus(PastDraconicGlories, :self.master);
    };
  };
};
